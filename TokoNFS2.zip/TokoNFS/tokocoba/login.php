<?php
session_start();
include 'koneksi.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(135deg, #6a11cb, #2575fc);
      font-family: 'Arial', sans-serif;
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0;
    }
    .login-container {
      background: #ffffff;
      border-radius: 20px;
      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
      padding: 2rem;
      width: 100%;
      max-width: 400px;
    }
    .login-container h3 {
      color: #333333;
      margin-bottom: 1.5rem;
      font-weight: bold;
    }
    .form-label {
      font-weight: 600;
      color: #555555;
    }
    .form-control {
      border-radius: 10px;
      box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    .btn-primary {
      background: linear-gradient(135deg, #2575fc, #6a11cb);
      border: none;
      border-radius: 20px;
      padding: 0.75rem 1.5rem;
      transition: all 0.3s ease;
    }
    .btn-primary:hover {
      background: linear-gradient(135deg, #6a11cb, #2575fc);
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
    }
    .icon {
      font-size: 2.5rem;
      color: #6a11cb;
      margin-bottom: 1rem;
    }
  </style>
</head>
<body>
  <div class="login-container">
    <div class="text-center">
      <i class="icon bi bi-person-circle"></i>
      <h3>Welcome Back</h3>
    </div>
    <form method="POST">
      <div class="mb-3">
        <label for="username" class="form-label">Username</label>
        <input type="text" class="form-control" id="username" name="username" placeholder="Enter username" required>
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" class="form-control" id="password" name="password" placeholder="Enter password" required>
      </div>
      <div class="text-center">
        <button type="submit" name="simpan" class="btn btn-primary fw-bold">Login</button>
      </div>
    </form>
  </div>
  <?php
if (isset($_POST["simpan"])) {
	$username = $_POST["username"];
	$password = $_POST["password"];
	$ambil = $koneksi->query("SELECT * FROM pengguna WHERE username='$username' AND password='$password' LIMIT 1");
	$akunyangcocok = $ambil->num_rows;

	if ($akunyangcocok == 1) {
		$akun = $ambil->fetch_assoc();

		if ($akun['level'] == "Pelanggan") {
			$_SESSION["pengguna"] = $akun;
			echo "<script>alert('Anda sukses login');</script>";
			echo "<script>location ='index.php';</script>";
		} elseif ($akun['level'] == "Admin") {
			$_SESSION['admin'] = $akun;
			echo "<script>alert('Anda sukses login');</script>";
			echo "<script>location ='admin/index.php';</script>";
		} 
	} else {
		echo "<script>alert('Anda gagal login, Cek akun Anda');</script>";
		echo "<script>location ='login.php';</script>";
	}
}
?>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.js"></script>
</body>
</html>


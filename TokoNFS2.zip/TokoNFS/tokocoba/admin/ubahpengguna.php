<div class="row">
    <div class="col-md-12 mb-4">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Edit Pengguna</h6>
            </div>
            <div class="card-body">
            <?php
// Ambil id dari URL
$id = $_GET['id'];

// Ambil data pengguna berdasarkan id
$ambil = $koneksi->query("SELECT * FROM pengguna WHERE id='$id'");
$pecah = $ambil->fetch_assoc();
?>


                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label class="control-label">Nama</label>
                        <input type="text" name="nama" class="form-control" value="<?php echo $pecah['nama']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Username</label>
                        <input type="username" name="username" class="form-control" value="<?php echo $pecah['username']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Password</label>
                        <input type="text" name="password" class="form-control" value="<?php echo $pecah['password']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Alamat</label>
                        <textarea class="form-control" name="alamat" required><?php echo $pecah['alamat']; ?></textarea>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Telepon</label>
                        <input type="text" name="telepon" class="form-control" value="<?php echo $pecah['telepon']; ?>">
                    </div>
                    <button class="btn btn-primary" name="update"><i class="glyphicon glyphicon-saved"></i> Simpan Perubahan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
if (isset($_POST["update"])) {
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];

    // Update data pengguna
    $koneksi->query("UPDATE pengguna SET 
                        nama='$nama', 
                        username='$username', 
                        password='$password', 
                        alamat='$alamat', 
                        telepon='$telepon' 
                    WHERE id='$id'");

    echo "<script>alert('Data Berhasil Diupdate')</script>";
    echo "<script>location='index.php?halaman=pengguna';</script>";
}
?>

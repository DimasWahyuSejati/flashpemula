<div class="row">
	<div class="col-md-12 mb-4">
		<div class="card shadow mb-4">
			<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
				<h6 class="m-0 font-weight-bold text-primary">Tambah Pengguna</h6>
			</div>
			<div class="card-body">
				<form method="post" enctype="multipart/form-data">
					<div class="form-group">
						<label class="control-label">Nama</label>
						<input type="text" name="nama" class="form-control" required>
					</div>
					<div class="form-group">
						<label class="control-label">Username</label>
						<input type="username" name="username" class="form-control" required>
					</div>
					<div class="form-group">
						<label class="control-label">Password</label>
						<input type="text" name="password" class="form-control" required>
					</div>
					<div class="form-group">
						<label class="control-label">Alamat</label>
						<textarea class="form-control" name="alamat" required></textarea>
					</div>
					<div class="form-group">
						<label class="control-label">Telepon</label>
						<input type="text" name="telepon" class="form-control">
					</div>
					<button class="btn btn-primary" name="daftar"><i class="glyphicon glyphicon-saved"></i>Simpan</a></button>

				</form>
			</div>
		</div>
	</div>
</div>

<?php
if (isset($_POST["daftar"])) {
	$nama = $_POST['nama'];
	$company = $_POST['company'];
	$tanggallahir = $_POST['tanggallahir'];
	$jeniskelamin = $_POST['jeniskelamin'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$alamat = $_POST['alamat'];
	$telepon = $_POST['telepon'];
	$ambil = $koneksi->query("SELECT*FROM pengguna 
							WHERE username='$username'");
	$yangcocok = $ambil->num_rows;
	if ($yangcocok == 1) {
		echo "<script>alert('Pendaftaran Gagal, username sudah ada')</script>";
		echo "<script>location='daftar.php';</script>";
	} else {
		$koneksi->query("INSERT INTO pengguna	(nama, username, password, alamat, telepon, level)
								VALUES('$nama','$username','$password','$alamat','$telepon','Pelanggan')");
		echo "<script>alert('Data Berhasil Ditambah')</script>";
		echo "<script>location='index.php?halaman=pengguna';</script>";
	}
}
?>
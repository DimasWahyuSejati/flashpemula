    <!-- Copyright -->
    <div class="text-center border-top pt-3 mt-3">
      <p class="mb-0 small">
        Copyright &copy; 2024 Nippon Vape Store. All Rights Reserved
      </p>
    </div>
  </div>
</footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="javascript/main.js"></script>
  </body>
</html>
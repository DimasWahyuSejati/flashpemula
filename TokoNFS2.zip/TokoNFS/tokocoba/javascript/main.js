document.querySelectorAll('.btnDetail').forEach(item => {
    item.addEventListener('click', (e) => {
        // Mendapatkan elemen card terkait

        console.log('Tombol Detail diklik');
        let parent = e.target.closest('.card');

        // Mengambil informasi dari card
        let gambar = parent.querySelector('.card-img-top').src;
        let harga = parent.querySelector('.harga').textContent;
        let judul = parent.querySelector('.card-title').textContent;
        let deskripsi = parent.querySelector('.card-text') ? parent.querySelector('.card-text').textContent : '<i>Deskripsi tidak tersedia</i>';

        // Menampilkan modal
        let tombolModal = document.querySelector('.btnmodal');
        tombolModal.click();

        // Memperbarui konten modal
        document.querySelector('.modalTitle').textContent = judul;

        let image = document.createElement('img');
        image.src = gambar;
        image.classList.add('w-100');
        document.querySelector('.modalImage').innerHTML = '';
        document.querySelector('.modalImage').appendChild(image);

        document.querySelector('.modalDeskripsi').innerHTML = deskripsi;
        document.querySelector('.modalHarga').textContent = harga;

        // Menyiapkan tautan ke WhatsApp
        const noHp = '6281239298220';
        const pesan = `Halo, Produk Kie Redy Ju: %0A*${judul}*%0AHarga: ${harga}%0A`;
        const waUrl = `https://api.whatsapp.com/send?phone=${noHp}&text=${encodeURIComponent(pesan)}`;

        document.querySelector('.btnBeli').href = waUrl;
    });
});

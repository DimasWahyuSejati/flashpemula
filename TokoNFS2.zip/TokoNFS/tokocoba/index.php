<?php
session_start();
include 'koneksi.php';
?>

<?php include 'header.php'; ?>
    <!-- Banner -->
    <div class="container border mb-4 mt-4 rounded-3 shadow bg-white p-3">
      <div class="px-4 mb-4">
        <img src="image/banner.jpg" class="w-100 rounded-3 banner" alt="Banner">
      </div>
      
      <!-- Tentang Kami -->
      <div class="tentang-kami-section mb-4" id="tentang-kami">
        <h3 class="text-uppercase mb-3 text-center">Tentang Kami</h3>
        <div class="tentang-kami-content">
          <!-- Gambar -->
          <img src="image/toko .jpg" alt= "tentang Kami" class="tentang-kami-img">
          <!-- Teks -->
          <div class="text">
            <p class="tentang-kami-text">
              <strong>Nippon Vape Store</strong> adalah toko rokok elektrik terpercaya yang menawarkan produk berkualitas dan layanan terbaik. Kami menyediakan beragam perlengkapan vaping untuk memenuhi kebutuhan Paru-Paru.
            </p>
          </div>
        </div>
      </div>
      
      <!-- Produk Kami -->
      <div class="section-title text-center" id="produk-kami">
        <hr>
        <h4>Produk Kami</h4>
      </div>
      <!-- Cards -->
      <div class="container">
        <div class="card-container">
          <div class="card shadow">
            <img src="image/Binggo.jpg" class="card-img-top">
            <div class="card-body">
              <h5 class="card-title">Binggo Vanila</h5>
              <p class="card-text">BINGO French Vanila Wafer 60ML</p>
            </div>
            <div class="card-footer d-flex justify-content-between">
              <a class="btn btn-sm btn-primary btnDetail">Detail</a>
              <span class="text-danger fw-bold harga">Rp. 120.000.00</span>
            </div>
          </div>
          <div class="card shadow">
            <img src="image/morning bang.jpg" class="card-img-top">
            <div class="card-body">
              <h5 class="card-title">Morning Beng</h5>
              <p class="card-text">Morning Beng wafer Chocolate 60ML</p>
            </div>
            <div class="card-footer d-flex justify-content-between">
              <a class="btn btn-sm btn-primary btnDetail">Detail</a>
              <span class="text-danger fw-bold harga">Rp. 140.000.00</span>
            </div>
          </div>
          <div class="card shadow">
            <img src="image/mufin cake.jpg" class="card-img-top">
            <div class="card-body">
              <h5 class="card-title">Mufin Cake</h5>
              <p class="card-text">Mufin Cake Strawbary 60ML.</p>
            </div>
            <div class="d-none"></div>
            <div class="card-footer d-flex justify-content-between">
              <a class="btn btn-sm btn-primary btnDetail">Detail</a>
              <span class="text-danger fw-bold harga">Rp. 114.000.00</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Button trigger modal -->
<button type="button" class="btn btn-primary d-none btnmodal" data-bs-toggle="modal" data-bs-target="#exampleModal">
  Launch demo modal
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5 modalTitle" id="exampleModalLabel"></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body row align-items-start">
        <div class="row">
        <!-- Kolom 1 -->
        <div class="col-md-6 col-12">
          <img src="image/Binggo.jpg" class="card-img-top" alt="Banner">
        </div>
        <!-- Kolom 2 -->
        <div class="col-md-6 col-12">
          <div class="modalDeskripsi mb-3">
            <p>Binggo Frence Vanila Wafer 60ML </p>
          </div>
          <div class="card-footer d-flex justify-content-between">
            <a href="https://wa.me/+6283896651569" class="btn btn-sm btn-warning btnBeli">Beli Produk Ini</a>
            <span class="text-danger fw-bold modalHarga">Rp. 120.000.00</span>
          </div>
        </div>
      </div>
      </div>
      <div class="modal-footer d-none">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<footer class="footer bg-dark text-white py-4" id="kontak-kami">
  <div class="container">
    <div class="row">
      <!-- Kolom 1: Deskripsi -->
      <div class="col-md-6 mb-3">
        <h4 class="fw-bold mb-2">NFS</h4>
        <p class="small">
           Nippon Vape Store merupakan Toko Vape baru didirikan pada yang menyediakan Liquid Vape beragam Varian dan Harga
        </p>

        <div class="mt-3">
          <h5 class="fw-bold mb-2">SOSIAL MEDIA</h5>
          <div class="d-flex gap-2 mb-2">
            <a href="https://wa.me/+6283896651569" class="text-white fs-4"><i class="bi bi-whatsapp"></i></a>
          </div>
          <!-- Beranda Link -->
          <div class="text-center mt-2">
            <a href="#" class="text-white fw-bold text-decoration-none">Beranda</a>
          </div>
        </div>
      </div>

      <!-- Kolom 2: Google Maps -->
      <div class="col-md-6 mb-3">
        <h5 class="fw-bold mb-2">LOKASI KAMI</h5>
        <div class="rounded overflow-hidden shadow">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3954.629513306029!2d109.40995550000001!3d-7.615230499999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e65490b2f55887b%3A0x2de6faf8c629a459!2sNFS%20Vapestore!5e0!3m2!1sen!2sid!4v1735444224004!5m2!1sen!2sid"
            width="100%"
            height="300"
            style="border:0;"
            allowfullscreen=""
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade">
          </iframe>
        </div>
      </div>
    </div>
    <?php
include 'footer.php';
?>



<?php
include 'koneksi.php';
?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>NFS</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    .custom-navbar {
      margin-bottom: 20px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .banner {
      max-height: 400px;
      object-fit: cover;
    }

    .tentang-kami-section {
      background-color: dimgray;
      color: white;
      padding: 1.5rem;
      border-radius: 5px;
    }

    .tentang-kami-img {
      width: 100%;
      max-width: 250px;
      height: auto;
      border-radius: 15px;
    }

    .tentang-kami-text {
      text-align: justify;
      font-size: 1rem;
      line-height: 1.6;
      letter-spacing: 0.5px;
    }

    .tentang-kami-content {
      display: flex;
      flex-wrap: wrap;
      gap: 1.5rem;
      align-items: center;
      justify-content: center;
    }

    .tentang-kami-content .text {
      flex: 1;
      max-width: 600px;
    }

    .card-container {
      display: flex;
      flex-wrap: wrap;
      gap: 5rem;
      justify-content: center;
    }

    .card {
      flex: 1;
      max-width: 300px;
    }

    .section-title hr {
      width: 50px;
      height: 3px;
      background-color: black;
      border: none;
      margin: 0.5rem auto;
    }

    .modal-body {
      display: flex;
      direction: column;
      align-items: center;
      gap: 15px;
    }

    .modalImagge img {
      max-width: 100%;
      height: auto;
      border-radius: 8px;
    }

    .modal-details {
      text-align: center;
      width: 100%;
    }

    .modalDeskripsi {
      margin-bottom: 10px;
      font-size: 1rem;
      color: #555;
    }

    .modal-details .btnBeli {
      display: inline-block;
      margin: 10px 0;
      background-color: #ffc107;
      color: #000;
      border: none;
      padding: 10px 20px;
      border-radius: 5px;
      font-weight: bold;
      text-decoration: none;
    }

    .modal-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .modalHarga {
      font-size: 1.2rem;
      font-weight: bold;
      color: #d9534f;
    }
  </style>
</head>

<body class="bg-light">
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-light bg-dark sticky-top custom-navbar border-bottom">
    <div class="container">
      <a class="navbar-brand fw-bold" href="#">
        <h1 class="m-0 text-light">NFS</h1>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link text-light fw-bold" href="#tentang-kami">Tentang Kami</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-light fw-bold" href="#produk-kami">Produk Kami</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-light fw-bold" href="#kontak-kami">Kontak Kami</a>
          </li>
          <?php
          if (isset($_SESSION["pengguna"])) {
            $id = $_SESSION["pengguna"]['id'];
            $ambil = $koneksi->query("SELECT * FROM pengguna WHERE id='$id'");
            $pecah = $ambil->fetch_assoc();
          ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle text-light fw-bold" href="#" id="akunDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Halo, <?php echo htmlspecialchars($pecah['nama']); // Menampilkan nama akun 
                      ?>
              </a>
              <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="akunDropdown">
                <li><a class="dropdown-item" href="logout.php">Logout</a></li>
              </ul>
            </li>
          <?php
          } else {
          ?>
            <li class="nav-item">
              <a class="btn btn-primary text-light fw-bold" href="login.php">Login</a>
            </li>
          <?php
          }
          ?>

        </ul>
      </div>
    </div>
  </nav>
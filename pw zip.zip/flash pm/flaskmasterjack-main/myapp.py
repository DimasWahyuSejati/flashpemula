from flask import, jsonify, request

app = Flask(__name__)

users = [
    {"id: 1", "name", "Dimas", "email" : "Dimas@gamil.com"}
    {"id: 2", "name", "Wahyu", "email" : "Wahyu@gamil.com"}
]

@app.route('/users', methods=['GET'])
def get_users():
    return jsonify({"users": users}), 200

@app.route('users/<int:user_id>', method=['GET'])
def get_user(user_id):
    user = next(
        (
          u for u in users if u["id"] == user_id      
        ), None
         
    )
    if user:
        return jsonify({"users": user}), 200
    return jsonify({"massage": "Gak Ada Bolo"}), 200

@app.route('/users', methods=['POST'])
def created_user():
    data = request.get_json
    new_user = {
        "id": len(users) + 1
        "name": data["name"]
        "email": data["email"]
    }
    users.append(new_user)
    return jsonify({"massage": "Data Berhasil Ditambahkan", "user": new_user}),

if __name__ == '--main--':
    app.route(debug=True)